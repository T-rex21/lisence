-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2183900)
addappid(2183901,0,"8df236a6a5084039477362b31157e7e0eb66554a744762d6782c544ab64d0c4e")
addappid(2486150)
addappid(2792140)
addappid(2792150)
addappid(2792170)
addappid(2792180)
addappid(2792190)
addappid(2792280)
addappid(3202690,0,"00c47f82b08192958b11307abb87c755003eb8dfae75063373e379c296b26083")
addappid(3212040,0,"e3818ce0f203d78eed2647e6364bd19a702fd8d7a01230f77a038e0fd26b0ffb")
addappid(3274400)
addappid(3274410)
addappid(3274430)
addappid(3274440)
addappid(3871320)
addappid(3871330)
addappid(3871340)
