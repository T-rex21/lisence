-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2592160)
addappid(2592161,0,"5b4a3a4477e47584b99200004c6f4ef8cf41be05df586de9e1771e160fc7527d")
addappid(3920280)
