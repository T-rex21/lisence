-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1627720)
addappid(1627721,0,"d847ff3494ad5b72d69b7b38c52474fdb22d437421b569013dd1508d8879f7c1")
addappid(1627722,0,"b2550c254da0b229ff5f5bb765b809d2fac5bd74a98ff3611b8cb8870e02aa6a")
addappid(2325280)
addappid(2325281)
addappid(2848330)
