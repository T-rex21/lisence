-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(108600)
addappid(108602,0,"2c6834d3d5c0e48329883a18abe5614aa868c3e7911fc582c613cec21b3a5d1c")
addappid(108603,0,"0b2a31059fa239993389b69ca9a0bebd9e3cbc8ccb446335c2becbe85060b0c4")
addappid(108604,0,"3f8e8c70818c5469711aeaefe50b4f280028b72dfd7f7a4c83b6bd747e4a382a")
