-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(553850)
addappid(553851,0,"6b40282b237b0cafc4d89014b5ec5f925f9aaa02f2d37f4d956acffdde2e0219")
addappid(553853,0,"5422d63966f1d6febad8f7e2d1bc3a1640844ae17bae7fc242dc6c1f97b99f3a")
addappid(553854,0,"43e8d494c23afa2317d5826d1ee2d87cf5657f1ce353df53190884b375a35ddd")
addappid(2506210,0,"05abf775a5f6aa84691b609ba4f72b7145a525d3ad96f40a370fedb0ca56e18e")
addappid(2506220,0,"7ad81ca560ac5347639df776f2ac89be13e39105f7413a162fc1fd87ba07daf7")
addappid(2506240,0,"55e8d00f742f81908503ca513f319ee3232b0d879972ea6c37106b59d72e9228")
addappid(2506250,0,"cdea2884539afaec7b221d45ee7692d076b02fd50763c20a094d58c05cba9574")
addappid(2506260,0,"85c9cfc1c96f01987c5bbf0b9be3cb58b760e512494cd167600197309d544526")
addappid(2506270,0,"f80e19955c82b4f235d52f44da578439b0f93d36f489db81e9fcc8b88dd56fab")
addappid(2506280,0,"15458a3b5a528df081b8c9c7702c90c4ccdcad2901e001c4adf7dae4c7229c4d")
addappid(2506300)
addappid(2514120)
addappid(2514130)
addappid(2521690)
addappid(2765950)
addappid(3118530)
addappid(3165780)
