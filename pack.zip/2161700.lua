-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(228988)
addappid(228989)
addappid(228990)
addappid(2161700)
addappid(2161701,0,"9644c57e48eb13144cd26fa9423b85051e1c474221f8f6cfcb017478cd8f3503")
addappid(2322840)
addappid(2334530)
addappid(2334531)
addappid(2334532)
addappid(2334533)
addappid(2334534)
addappid(2334535)
addappid(2334536)
addappid(2517300)
addappid(2517310)
addappid(2689210)
