-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1693980)
addappid(1693981,0,"9738ac7c4b941978165b403d5785d6c8c331366f7feb30c0b276401fd71f4ccb")
addappid(2164210)
