-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2552430)
addappid(229002)
addappid(2552433,0,"3048ac569ea91341059d2691e5704b419438924647bbfff862306100e954d729")
addappid(2552432,0,"54623f7b577384d4941f13992f4a616bb970dff6b7da182910216abdd80e2963")
addappid(2552435,0,"a80c9e6c188b860963b1522a22e2cdae021b00f1efc74ab0e71ecbd3a5eab887")
addappid(2552434,0,"f1a97978987d237956d5eb9bd21c2d07893802e9d883dabe2b734422e1671da3")
addappid(2552437,0,"a03d38720489ac783bf0a3fa809533877e5500085e65b689b16e89ab107267c9")
addappid(2552436,0,"12ac15423ee79d30b6e9ce496884ba87b989618432a7f64e752343e910e47886")
